fun main() {
    var oezd = vagon(0, "", "", 0, 0, 0, )
        oezd.Info()
        oezd.Vid()
        oezd.Output()
    }
