abstract class train(override var number:Int, override var punktopr:String,override var punktnaz:String,override var timeot:Int,override var vremyav: Int,override var timeprib: Int):trata
{
    override fun Info(){
        try {
            println("Введите номер поезда")
            number = readln()!!.toInt()
            println("Введите пункт отправления")
            punktopr = readLine().toString()
            println("Введите пункт назначения")
            punktnaz = readLine().toString()
            println("время отправления")
            timeot = readLine()!!.toInt()
            println("время прибытия")
            timeprib = readLine()!!.toInt()
            vremyav = timeprib-timeot
        } catch (e:Exception) {println("nonononono")}
    }
    override fun Output()
    {
        println("номер поезда: ${number},пункт отправления: ${punktopr},пункт назначения: ${punktnaz}, время отправления: ${timeot},время прибытия: ${timeprib},время в пути: ${vremyav}")
    }
}