interface trata {
    fun Info()
    fun Output()
    var number: Int
    var punktopr: String
    var punktnaz: String
    var timeot: Int
    var timeprib:Int
    var vremyav: Int

}