class vagon (number:Int,punktopr:String,punktnaz:String,timeot:Int,vremyav: Int, timeprib: Int):train(number,punktopr,punktnaz,timeot,vremyav,timeprib){
    fun Vid()
    {
        println("-ура приехали")
        if (vremyav>20)
        {
            println("-Очень долго вы ехали, сделайте разминку")
        }
        else if (vremyav>15)
        {
            println("-я бы устал честное слово")
        }
        else if (vremyav>10)
        {
            println("-время быстро пролетело")
        }
        else if (vremyav<10)
        {
            println("-уже приехали?")
        }
        else {
            println("-вы похоже стояли на месте")
        }
    }

}